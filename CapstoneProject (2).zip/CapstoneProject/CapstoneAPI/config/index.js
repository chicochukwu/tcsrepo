module.exports = {
    jwtSecret: "Random string for a jwt token!"
};