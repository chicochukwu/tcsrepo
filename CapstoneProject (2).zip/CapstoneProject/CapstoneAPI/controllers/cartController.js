const Item = require('../models/item');
const User = require('../models/user');


exports.addToCart = async (req, res, next) => {
    try{
    
        User.findOneAndUpdate({_id: req.params.userid}, 
            {$push: {"cart": {_id: req.params.productid}}},
            {new:true},
            (err, doc) => {
                if(err){
                    console.log(err);
                } else {
                    res.status(200).json(doc.cart)
                }
            }
            );
        
    }catch(err){
        next(err);
    }
}
/*
exports.updateCart = async (req, res, next) => {
    try {
        // edit size, quantity
        let cart = Cart();
        cart.item = await Item.findById(req.params.id);
    
        cart = await cart.save();
        res.send(cart);

    } catch(err) {
        next(err)
    }
};

*/

exports.getCartList = async (req, res, next) => {
    try {
        const cart = await Cart.find({});
        res.send(cart);

    } catch(err) {
        next(err)
    }
};

exports.getCartListByUser = async (req, res, next) => {
    try {
        let user = await User.findById({_id: req.params.userid})
        //console.log(user.cart);

        res.send(user.cart);

    } catch(err) {
        next(err)
    }
};

