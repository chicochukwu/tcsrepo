const Item = require('../models/item');
const User = require('../models/user');

exports.store = async (req, res, next) => {
    try {
        let user = await User.findOne({_id: req.params.id});
        if (!user){
            throw new Error("user not found");
        }
        else{
            let item = new Item();
            item.name = req.body.name;
            item.quantity = req.body.quantity;
            item.price = req.body.price;
            item.size = req.body.size;
            item = await item.save();
           res.send({ user, item});
        }
     
        

    } catch(err) {
        next(err)
    }
};

exports.show = async (req, res, next) => {
    try {
      
        const item = await Item.findOne({
            _id: req.params.id
        })
        res.send(item);
    } catch(err){
        next(err);
    }
};

exports.showall = async (req, res, next) => {
    try {
        const item = await Item.find({});

        res.send(item);
    } catch(err){
        next(err);
    }
};


exports.update = async(req, res, next) => {
    try{
        let item = await Item.findById(req.params.id);
        item.name = req.body.name;
        item.price = req.body.price;
        item.quantity = req.body.quantity;
        item.size = req.body.size;

        item = await item.save();

        res.send({message: "item is updated"}, {item});
    } catch(err){
        next(err);
    }
    
};

exports.delete = async (req, res, next) => {
    try {
        
        let item = await Item.findById(req.params.id);
        await item.delete();
        res.send({message: 'item is deleted'});
    } catch (err) {
        next(err)
    }
};