const User = require('../models/user');
const config = require("../config");
const jwt = require("jwt-simple");

exports.signup = async (req, res, next) => {
    try {

        const existingUser = await User.findOne({username: req.body.username});
        if (existingUser) {
            const error = Error("Username is already in use");
            error.statusCode = 403;
            throw error;
        }

        let user = new User();
        user.username = req.body.username;
        user.password = await user.encryptPassword(req.body.password);
        user.role = req.body.role;
        user.cart = [];
        const token = jwt.encode({ id: user.id}, config.jwtSecret);
        user.token = token;

        user = await user.save();
        return res.send({user, token});

    } catch(err) {
        next(err)
    }
};

exports.login = async (req, res, next) =>{
    try {
        const username = req.body.username;
        const password = req.body.password;

        // select password field. not selected by default
        const user =  await User.findOne({ username }).select("+password");

        if(!user) {
            const error = new Error("Wrong Credentials");
            error.statusCode = 401;
            throw error;
        }

        const validPassword = await user.validPassword(password);
        if(!validPassword){
            const error = new Error("Wrong Credentials");
            error.statusCode = 401;
            throw error;
        }

        const token = jwt.encode({ id: user.id}, config.jwtSecret)
        return res.send({ user, token });

    } catch(err) {
        next(err);
    }
}
// find a user
exports.me = async (req, res, next) => {
    try {
        const user = await User.findById(req.params.id).select("+token");
        return res.send(user);
    } catch (err) {
        next(err);
    }
}; 

exports.getUsers = async (req, res, next) => {
    try {
        const users = await User.find({}).select("+token");
        return res.send(users);
    } catch (err) {
        next(err);
    }
}; 

