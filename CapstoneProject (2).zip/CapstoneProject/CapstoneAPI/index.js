const express = require('express');
var path = require('path');
const cors = require('cors');
const bodyParser = require('body-parser');
const mongoose = require('mongoose');
const passportJWT = require('./middlewares/passportJWT')(); 

const itemRoutes = require('./routes/item');
const authRoutes = require('./routes/auth');
const cartRoutes = require('./routes/cart');
const PORT = 3000;
const app = express();

app.use(cors());


/* config for mongoose db */
const uri =  "mongodb+srv://reguser:reguserpass@theogcluster.v95vw.mongodb.net/CAPSTONE?retryWrites=true&w=majority";
mongoose.Promise = global.Promise;
mongoose.connect(uri, {useNewUrlParser: true, useUnifiedTopology:true }).
    catch(error => console.log("Could not connect to database", error));

app.use(bodyParser.json());
app.use(bodyParser.urlencoded({extended:true})); // for url stuff
app.use(express.static(path.join(__dirname, "public")));
app.use(passportJWT.initialize());

app.use("/api/item",  itemRoutes);
app.use("/api/auth", authRoutes);
app.use("/api/cart", cartRoutes);

app.listen(PORT, () => {
    console.log('Listening');
});