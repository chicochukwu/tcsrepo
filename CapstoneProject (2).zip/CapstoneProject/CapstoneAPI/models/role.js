const roles = {
    admin: 'admin' || 'Admin' || 'ADMIN',
    user: 'user' || 'User' || 'USER'
}

module.exports = {
   roles
}