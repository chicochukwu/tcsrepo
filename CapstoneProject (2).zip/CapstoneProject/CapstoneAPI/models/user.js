const mongoose = require('mongoose');
const bcrypt = require("bcryptjs");
const ROLE = require('./role');

const Schema = mongoose.Schema;

const UserSchema = new Schema({
    password: {type: String, required: true, select: false},
    username: {type: String, required: true},
    role: {type:ROLE, required: true},
    token: {type: String, required: false, select: false}, // for testing purposes
    cart: {}
});

UserSchema.methods.encryptPassword = async password => {
    const salt = await bcrypt.genSalt(5); //
    const hash = await bcrypt.hash(password, salt);
    return hash;
};

UserSchema.methods.validPassword = async function(enterdPassword)  {
    const result = await bcrypt.compare(enterdPassword, this.password);
    return result;
};

module.exports = mongoose.model("user", UserSchema, 'users');
