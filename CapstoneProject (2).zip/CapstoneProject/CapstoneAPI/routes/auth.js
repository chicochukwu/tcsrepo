const express = require('express');
const router = express.Router();
const passportJWT = require('../middlewares/passportJWT')(); 
const userController = require("../controllers/userController");

router.post("/signup", userController.signup);
router.post("/login",  userController.login);
router.get("/user/:id",  userController.me);
router.get("/getusers",  userController.getUsers);

module.exports = router; 