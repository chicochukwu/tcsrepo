const express = require('express');
const router = express.Router();
const itemController = require("../controllers/itemController");
const role = require('../models/role');
const passportJWT = require('../middlewares/passportJWT')(); 


router.post("/store/:id",   itemController.store);
router.get("/show/:id",  itemController.show);
router.get("/show",  itemController.showall);
router.put("/update/:id",  itemController.update);
router.delete("/delete/:id",  itemController.delete);

module.exports = router;
