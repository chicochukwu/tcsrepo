import { Injectable } from '@angular/core';
import { CanActivate, ActivatedRouteSnapshot, RouterStateSnapshot, UrlTree } from '@angular/router';
import { Observable } from 'rxjs';
import { UserService } from './services/user.service';

@Injectable({
  providedIn: 'root'
})
export class AdminGuardGuard implements CanActivate {

  constructor(private userService: UserService){}

  role: string;

  canActivate(
    route: ActivatedRouteSnapshot,
    state: RouterStateSnapshot): boolean {
    
    this.userService.getUserById(localStorage.getItem("userid")).subscribe(data => {
       
      this.role = data['role'];
    })

    if(this.role.toLowerCase() !== 'admin'){
      return false
    }
    else{
      return true;

    }
    

    }
  
}
