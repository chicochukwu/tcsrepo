import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { LoginComponent } from './components/login/login.component'
import { ItemComponent } from './components/item/item.component'
import { SignupComponent } from './components/signup/signup.component'
import { PageNotFoundComponent } from './components/page-not-found/page-not-found.component';
import { ItemCreateComponent } from './components/item/item-create/item-create.component';
import { ItemListComponent } from './components/item/item-list/item-list.component';
import { AdminGuardGuard } from './admin-guard.guard';


const routes: Routes = [
  {
    path:'signup', component: SignupComponent,
  },
  {
    path: 'login', component: LoginComponent
  },
  {
    path:'item/:userid', component: ItemComponent,
  },
  {
    path:'admin/:userid', component: ItemCreateComponent,
    canActivate: [AdminGuardGuard]
  },
  {
    path:'cart/:userid', component: ItemListComponent,
  },
  {
    path: '', redirectTo: '/signup', pathMatch:'full'
  },

  // add other routes here
   {
       path: '**', component: PageNotFoundComponent
   }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }

export const routingComponents = [
    LoginComponent, 
    SignupComponent, 
    ItemComponent, 
    ItemListComponent,
    PageNotFoundComponent
]


