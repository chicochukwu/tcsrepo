import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import {HttpClientModule} from '@angular/common/http';

import { AppRoutingModule, routingComponents } from './app-routing.module';
import { NavComponent } from './components/nav/nav.component';

import { AppComponent } from './app.component';
import { ItemListComponent } from './components/item/item-list/item-list.component';
import { PageNotFoundComponent } from './components/page-not-found/page-not-found.component';
import { ItemCreateComponent } from './components/item/item-create/item-create.component';


@NgModule({
  declarations: [
    AppComponent,
    NavComponent,
    routingComponents,
    ItemListComponent,
    PageNotFoundComponent,
    ItemCreateComponent,
  ],
  imports: [
    BrowserModule,
    HttpClientModule,
    AppRoutingModule,
    FormsModule,
    ReactiveFormsModule,

  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
