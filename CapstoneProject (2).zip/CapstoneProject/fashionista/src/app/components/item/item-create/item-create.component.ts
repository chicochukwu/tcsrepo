import { Component, OnInit, Output, EventEmitter } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { ItemService } from 'src/app/services/item.service';
import { IItem } from '../../../models/item-model.model';

@Component({
  selector: 'app-item-create',
  templateUrl: './item-create.component.html',
  styleUrls: ['./item-create.component.css']
})
export class ItemCreateComponent implements OnInit {

  constructor(private itemService: ItemService, protected formBuilder: FormBuilder) { }

  itemForm: FormGroup;
  name: string = '';
  price: number;
  quantity: number;
  size: string[];
  userid: string;
  error: boolean = false;
  
  public itemList = [];

  @Output() createdProduct = new EventEmitter<IItem>();

  onSubmit(){
    this.userid = localStorage.getItem("userid");
    this.itemService.addItem(this.userid, this.itemForm.value)
      .subscribe(data => {
         console.log(data)
         if (data === undefined) {
           this.error = true
         }
         else{
           this.createdProduct.emit(data)
          }
        this.getItemsFromService();
      });
  }

  getItemsFromService(){  
    this.itemService.getItems()
      .subscribe(data => this.itemList = data);
  }


  // Hide the error message.
  hideError() {
    this.error = false;
  }
  update(id: string){
    this.itemService.updateItem(id).subscribe(data =>{

      this.getItemsFromService();
    })
  }
  delete(id:string){
    this.itemService.deleteItem(id)
      .subscribe(data =>{
        this.getItemsFromService();
      })
  }

  // Init the creation form.
  private initForm() {
    this.itemForm = new FormGroup({
      name: new FormControl(this.name, Validators.required),
      price: new FormControl(this.price, Validators.required),
      quantity: new FormControl(this.quantity, Validators.required),
      size: new FormControl(this.quantity, Validators.required)
    });
  }
  ngOnInit(): void {
    this.initForm();
    this.getItemsFromService();
  }

}
