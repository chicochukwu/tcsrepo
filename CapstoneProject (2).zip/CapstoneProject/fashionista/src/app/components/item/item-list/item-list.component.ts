import { Component, OnInit, Input, OnChanges } from '@angular/core';
import { CartService } from 'src/app/services/cart.service';
import { ItemService } from 'src/app/services/item.service';
import {IItem} from '../../../models/item-model.model';
@Component({
  selector: 'app-item-list',
  templateUrl: './item-list.component.html',
  styleUrls: ['./item-list.component.css']
})
export class ItemListComponent implements OnInit {

  constructor(private cartService: CartService, private itemService: ItemService) { }
  
  cartItems = [];
  ngOnInit(): void {
    this.retrieveAddedCartItems();
  }

  retrieveAddedCartItems(){
    console.log("userid",localStorage.getItem("userid"))
    this.cartService.getItemsFromCartServiceByUser(localStorage.getItem("userid"))
      .subscribe(data => {
        console.log("Data from cart service",data)
           // logs id of item
         this.cartItemList(data)
      });
  }

  cartItemList(data){
    for(let i = 0; i < data.length; i++){
      this.itemService.getOneItemFromService(data[i]['_id']).subscribe(data => {
        this.cartItems.push(data);
  
      })
    }
  }

  purchase(id: string, event:any){
    event.target.disabled = true;
    alert("Thanks for your purchase");

  }

  
}
