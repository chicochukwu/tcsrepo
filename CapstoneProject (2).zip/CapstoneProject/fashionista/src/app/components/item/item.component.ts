import { Component, Input, OnInit, Output, EventEmitter } from '@angular/core';
import { ItemService } from '../../services/item.service';
import { UserService } from '../../services/user.service';
import { CartService } from '../../services/cart.service';
import { IItem } from '../../models/item-model.model';

@Component({
  selector: 'app-item',
  templateUrl: './item.component.html',
  styleUrls: ['./item.component.css'],
  providers: [ItemService, UserService, CartService]
})
export class ItemComponent implements OnInit {
  public items = [];
  public cartItems = [];
  
  public cartItemsOfId = [];
  @Output() addedItemToCart = new EventEmitter<any>();

  userid
  clicked = false;
  constructor(private itemService: ItemService, private cartService: CartService) { }

  getItemsFromService(){
    this.itemService.getItems()
      .subscribe(data => this.items = data);
  }

  getUserById(){
   
  }
  ngOnInit(): void {
    this.getItemsFromService();
  }

  getItemsFromCart(){
    this.cartService.getItemsFromCartService()
      .subscribe(data => this.cartItems = data);
      // send cart items to item-list for checkout
  }

  purchase(id: string, event:any){
    this.itemService.getOneItemFromService(id)
    // get item from list of item
      .subscribe(data => {

        this.userid = localStorage.getItem("userid"); // it works

        // send item to cart service
        this.cartService.addItemToCart(this.userid, id).subscribe(data => {
          event.target.disabled = true;

          this.cartItemsOfId = data;
        }) 

      });

  }

}
