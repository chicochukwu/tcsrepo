import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl } from '@angular/forms';
import { UserService } from '../../services/user.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css'],
  providers:[UserService]
})
export class LoginComponent implements OnInit {

  constructor(private userService: UserService, private router: Router) { }

  myForm:FormGroup

  username:FormControl
  password:FormControl

  admin = "admin";
  userRole: string;
  userid: string;
  createFormControls () {
    this.username = new FormControl('')
    this.password = new FormControl('')
  }

  createForm(){
    this.myForm = new FormGroup({
      username:this.username,
      password:this.password
    })
  }

  login(){
    this.userService.loginValidate(this.myForm.value)
      .subscribe(data => {
   
        this.redirecTo(data);
      })
     
  }

  redirecTo(data: any){
    
      this.userRole = data["user"]["role"];
      this.userid = data['user']['_id'];

      if(this.userid){
        localStorage.setItem("userid", this.userid);
      }
      this.router.navigate(['/item', 'userid'])
      
  }

  redirectToSignup(){
    this.router.navigate(['/signup']);
  }
  ngOnInit(): void {
    this.createFormControls();
    this.createForm();
    localStorage.clear();
  }

}
