import { Component, OnInit } from '@angular/core';
import {NavComponent} from '../nav/nav.component';
import {LoginComponent} from '../login/login.component';
import {IUser} from '../../models/user-model.model';
import { FormGroup, FormControl } from '@angular/forms';
import { UserService } from '../../services/user.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-signup',
  templateUrl: './signup.component.html',
  styleUrls: ['./signup.component.css'],
  providers:[UserService]
})
export class SignupComponent implements OnInit {

  constructor(private userService: UserService, private router: Router) { }
    myForm:FormGroup

    username:FormControl
    password:FormControl
    role: FormControl

    userObj: any
    token: string
    userRole: string
    
    userid: string
    admin = 'admin';


  createFormControls () {
    this.username = new FormControl('');
    this.password = new FormControl('');
    this.role = new FormControl('');
  }

  createForm(){
    this.myForm = new FormGroup({
      username:this.username,
      password:this.password,
      role: this.role
    })
  }

  getUserData(){
    this.userService.userSignUp(this.myForm.value)
      .subscribe(data => {
        this.userObj = data;
        this.token = this.userObj['token'];
        this.userid = this.userObj['user']['_id'];
        this.userRole = this.userObj['user']['role'];

        if(this.userid){
          // send user id to itemComponent to send to addCart
          localStorage.setItem("userid", this.userid);
  
        }
        
        if(this.userRole.toLowerCase() === this.admin){
          this.router.navigate(['/admin', 'userid']); 
        }
        else{
          this.router.navigate(['/item', 'userid'])
        }
        
      });
    
  }
  redirectToLogin(){
    this.router.navigate(['/login']);

  }
  signup(){
    this.getUserData();
  }
  ngOnInit(): void {
    this.createFormControls();
    this.createForm();

  }

}
