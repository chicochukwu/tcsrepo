export interface IUser  {
    username: string;
    password: string;
    role: string;
    token: string;
    _id?: string;
}