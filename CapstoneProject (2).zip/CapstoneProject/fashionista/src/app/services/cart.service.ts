import { Injectable } from '@angular/core';
import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { IItem } from '../models/item-model.model';
import { Observable, throwError, BehaviorSubject, Subject } from 'rxjs';



@Injectable({
    providedIn: 'root'
})
export class CartService {
    private cartUrl = '/api/cart';
    

    constructor(private http: HttpClient) {

    }
    


    addItemToCart(userId, productId): Observable<any[]> {
        return this.http.post<any[]>(`${this.cartUrl}/${userId}/${productId}`, null);
      }

    getItemsFromCartService(): Observable<any[]> {
        return this.http.get<any[]>(this.cartUrl);
    }

    getItemsFromCartServiceByUser(userid: string): Observable<IItem[]> {
        return this.http.get<IItem[]>(`${this.cartUrl}/${userid}`);
    }
}