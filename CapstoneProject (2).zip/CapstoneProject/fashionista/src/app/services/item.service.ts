import { Injectable } from '@angular/core';
import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { IItem } from '../models/item-model.model';
import { Observable, throwError } from 'rxjs';



@Injectable({
    providedIn: 'root'
})
export class ItemService {
    private postItemUrl = '/api/item/store';
    private getItemUrl = '/api/item/show';
    private updateItemUrl = '/api/item/update';
    private deleteItemUrl = '/api/item/delete';

    constructor(private http: HttpClient) {}
    
    getItems(): Observable<IItem[]>{
        return this.http.get<IItem[]>(this.getItemUrl);
                        
    }
    getOneItemFromService(id: string): Observable<IItem> {
        return this.http.get<IItem>(`${this.getItemUrl}/${id}`);
    }

    addItem(userid: any, userObj: any): Observable<IItem>{
        return this.http.post<IItem>(`${this.postItemUrl}/${userid}`, userObj);
    }

    deleteItem(id:string): Observable<IItem[]>{
        return this.http.delete<IItem[]>(`${this.deleteItemUrl}/${id}`)
    }

    updateItem(id:string): Observable<IItem[]>{
        return this.http.delete<IItem[]>(`${this.updateItemUrl}/${id}`)
    }
    
}
