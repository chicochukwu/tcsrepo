import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { IUser } from '../models/user-model.model';
import { Observable, throwError } from 'rxjs';

@Injectable({
    providedIn: 'root'
})
export class UserService {
    private signUpUrl = '/api/auth/signup';
    private signInUrl = '/api/auth/login';
    private getUserUrl = '/api/auth/user';
    private getUsersUrl = '/api/auth/getusers';

    constructor(private http: HttpClient) {}
    
    loginValidate(userObject: any): Observable<IUser>{
        return this.http.post<IUser>(this.signInUrl, userObject);
    }

    userSignUp(userObject: any){
        return this.http.post(this.signUpUrl, userObject);
    }

    getUserById(id: string): Observable<IUser> {
        return this.http.get<IUser>(`${this.getUserUrl}/${id}`);
    }

    getAllUsers(){
        return this.http.get(this.getUsersUrl);
    }

}
